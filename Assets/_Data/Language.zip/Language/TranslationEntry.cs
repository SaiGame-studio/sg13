[System.Serializable]
public class TranslationEntry
{
    public string Key;
    public string Value;
}